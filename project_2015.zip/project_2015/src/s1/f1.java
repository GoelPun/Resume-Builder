package s1;

import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Date;
 
import com.itextpdf.awt.geom.Rectangle;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.List;
import com.itextpdf.text.ListItem;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class f1
{
	 public static void main(String[] args) 
	 {}
	 public f1()
	 {
	 
	 
	 
		 
		 
		 
	        try 
	        {
	            OutputStream file = new FileOutputStream(new File(mj7.path));
	 
	            Document document = new Document();
	            PdfWriter.getInstance(document, file);
	 
	            document.open();
	            
	           /* Rectangle pageSize = new Rectangle(PageSize.A4);
	             pageSize.setBackgroundColor(BaseColor.BLUE);*/
	           
	             
	             
	            String name=mj2.name;
	            Paragraph p1=new Paragraph(name);
	            p1.setAlignment(Element.ALIGN_RIGHT);
	            document.add(p1);
	            
	            String contact=mj2.contact;
	            Paragraph p2=new Paragraph(contact);
	            p2.setAlignment(Element.ALIGN_RIGHT);
	            document.add(p2);
	            
	            String email=mj2.email;
	            Paragraph p3=new Paragraph(email);
	            p3.setAlignment(Element.ALIGN_RIGHT);
	            document.add(p3);
	            
	            String address=mj2.address;
	            Paragraph p4=new Paragraph(address);
	            p4.setAlignment(Element.ALIGN_RIGHT);
	            document.add(p4);
	            
	            Font font1=new Font(Font.FontFamily.TIMES_ROMAN,14,Font.UNDERLINE | Font.BOLD);
	            Font font2=new Font(Font.FontFamily.TIMES_ROMAN,14,Font.BOLD);

	            Paragraph p5=new Paragraph("OBJECTIVE :                                                                                                                           ",font1);
	            p5.setAlignment(Element.ALIGN_LEFT);
	            p5.setSpacingAfter(12);
	            document.add(p5);
	            
	            String objective=mj4.objective;
	            Paragraph p6=new Paragraph(objective);
	            p6.setAlignment(Element.ALIGN_LEFT);
	            p6.setSpacingAfter(12);   
	            document.add(p6);
	            
	            String class10=mj5.c10;
	            String class10b=mj5.c10b;
	            String class12b=mj5.c12b;
	            String class12=mj5.c12;
	           // String class_graduate="9.66";
	            Paragraph p7=new Paragraph("QUALIFICATIONS :                                                                                                               ",font1);
	            p7.setAlignment(Element.ALIGN_LEFT);
	            p7.setSpacingAfter(12);
	            document.add(p7);
	            PdfPTable table1=new PdfPTable(3);
	           /* float []u={1,2};
	            table1.setWidths(u);*/
	            PdfPCell cell1 = new PdfPCell(new Paragraph("Class",font2));
	            cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);

	            PdfPCell cell2 = new PdfPCell(new Paragraph("%Marks",font2));
	            cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell2.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            PdfPCell cell7 = new PdfPCell(new Paragraph("Board",font2));
	            cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            table1.addCell(cell1);
	            table1.addCell(cell2);
	            table1.addCell(cell7);

	            PdfPCell cell3 = new PdfPCell(new Paragraph("10th"));
	            cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            PdfPCell cell4 = new PdfPCell(new Paragraph(class10));
	            cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            PdfPCell cell8 = new PdfPCell(new Paragraph(class10b));
	            cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            table1.addCell(cell3);
	            table1.addCell(cell4);
	            table1.addCell(cell8);

	            PdfPCell cell5 = new PdfPCell(new Paragraph("12th"));
	            cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            PdfPCell cell6 = new PdfPCell(new Paragraph(class12));
	            cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            PdfPCell cell9 = new PdfPCell(new Paragraph(class12b));
	            cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            
	            table1.addCell(cell5);
	            table1.addCell(cell6);
	            table1.addCell(cell9);

	           /* PdfPCell cell7 = new PdfPCell(new Paragraph("Graduate"));
	            cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            PdfPCell cell8 = new PdfPCell(new Paragraph(class_graduate));
	            cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            table1.addCell(cell7);
	            table1.addCell(cell8);*/
	            document.add(table1);
	            
	            
	            Paragraph p8=new Paragraph("TECHNICAL SKILLS :                                                                                                           ",font1);
	            p8.setAlignment(Element.ALIGN_LEFT);
	            p8.setSpacingAfter(12);
	            p8.setSpacingBefore(12);
	            document.add(p8);
	            
	           String [] tskills=new String[5];
	           tskills[0]=mj4.ts1;
	           

	           
	            List unorderedList1 = new List(List.UNORDERED);

	            for(int i=0;i<tskills.length;i++)
	            {
	            	unorderedList1.add(new ListItem(new Paragraph(tskills[i])));
	            }
	            document.add(unorderedList1);
	            
	           Paragraph p9=new Paragraph("HOBBIES :                                                                                                                                 ",font1);
	            p9.setAlignment(Element.ALIGN_LEFT);
	            p9.setSpacingAfter(12);
	            p9.setSpacingBefore(12);
	            document.add(p9);
	            
	            String hobbies[]=new String[5];
	            hobbies[0]=mj4.ts2;
	            List unorderedList2 = new List(List.UNORDERED);

	            for(int i=0;i<hobbies.length;i++)
	            {
	            	unorderedList2.add(new ListItem(new Paragraph(hobbies[i])));
	            }
	            document.add(unorderedList2);
	            
	            
	            
	            
	            
	            Paragraph p10=new Paragraph("EXTRA CURICULLAR ACTIVITIES :                                                                                ",font1);
	            p10.setAlignment(Element.ALIGN_LEFT);
	            p10.setSpacingAfter(12);
	            p10.setSpacingBefore(12);
	            document.add(p10);
	            
	            String ECA[]=new String[5];
	            ECA[0]=mj4.ts3;
	            List unorderedList3 = new List(List.UNORDERED);

	            for(int i=0;i<ECA.length;i++)
	            {
	            	unorderedList3.add(new ListItem(new Paragraph(ECA[i])));
	            }
	            document.add(unorderedList3);
	            
	            
	            
	           Paragraph p11=new Paragraph("ACHIEVEMENTS :                                                                                                                  ",font1);
	            p11.setAlignment(Element.ALIGN_LEFT);
	            p11.setSpacingAfter(12);
	            p11.setSpacingBefore(12);
	            document.add(p11);
	            
	            String achievements[]=new String[5];
	            achievements[0]=mj5.ts2;
	            List unorderedList4 = new List(List.UNORDERED);

	            for(int i=0;i<achievements.length;i++)
	            {
	            	unorderedList4.add(new ListItem(new Paragraph(achievements[i])));
	            }
	            document.add(unorderedList4);
	            
	            
	            
	            
	            
	            Paragraph p12=new Paragraph("STRENGTH :                                                                                                                            ",font1);
	            p12.setAlignment(Element.ALIGN_LEFT);
	            p12.setSpacingAfter(12);
	            p12.setSpacingBefore(12);
	            document.add(p12);
	            
	            String strength[]=new String[5];
	            strength[0]=mj5.ts1;
	            List unorderedList5 = new List(List.UNORDERED);

	            for(int i=0;i<strength.length;i++)
	            {
	            	unorderedList5.add(new ListItem(new Paragraph(strength[i])));
	            }
	            document.add(unorderedList5);   
	 
	            document.close();
	            file.close();
	 
	        } 
	        catch (Exception e) 
	        {
	            e.printStackTrace();
	        }
	 }
	

}
