package project_2015;
import s1.*;
public class control 
{
public static void main(String []args)
{
	new mj1().setVisible(true);
}
}
