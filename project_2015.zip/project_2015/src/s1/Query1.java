/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package s1;
import java.sql.*;
import java.util.Scanner;


public class Query1 extends Connect
{
	  String a,b,c;
    public void dbInsert(String s1,String s2,String s3,String s4)
    {
        try
       {
        	PreparedStatement ps=null;
        	
           
         ps=con.prepareStatement("insert into detail_company values('"+s1+"','"+s2+"','"+s3+"','"+s4+"')");
         ps.executeUpdate();
       }
       catch(Exception e)
       {
           System.out.println(e);
       }
    }
    
    
    
    void dbselect(String s1)
    {
        try
        {
     	   PreparedStatement ps=null;
     	   ResultSet rs=null;
     	  
     	  
     	  // String a=null,b=null,c=null;
            String val="select * from detail_company where Name ='"+s1+"' ";
          ps=con.prepareStatement(val);
          rs=ps.executeQuery();
          //System.out.println("Name\tID\tcontact");
         // System.out.println();
     

          while(rs.next())
          {
         	   
              a=rs.getString("Password");
               
          }
       
          
        }
        catch(Exception e)
        {
            System.out.println("jain"+e.getMessage());
        }
    }
    
   
}
