/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package s1;
import java.sql.*;
import java.util.Scanner;


public class Query extends Connect
{
	  String a,b,c;
    public void dbInsert(String s1,String s2,String s3,String s4,String s5,String s6 , String s7)
    {
        try
       {
        	PreparedStatement ps=null;
           
         ps=con.prepareStatement("insert into detail_student values('"+s1+"','"+s2+"','"+s3+"','"+s4+"','"+s5+"','"+s6+"','"+s7+"')");
         ps.executeUpdate();
       }
       catch(Exception e)
       {
           System.out.println(e);
       }
    }
    
    
    
    void dbselect(String s1)
    {
        try
        {
     	   PreparedStatement ps=null;
     	   ResultSet rs=null;
     	  
     	  
     	  // String a=null,b=null,c=null;
            String val="select * from detail_student";
          ps=con.prepareStatement(val);
          rs=ps.executeQuery();
          
          a="Name\tSex\tContact\tEmail-ID\tQualification\t%Marks\tAddress\n";
          while(rs.next())
          {
              a+=rs.getString("Name");
              a+="\t";
              a+=rs.getString("Sex");
              a+="\t";
              a+=rs.getString("Contact");
              a+="\t";
              a+=rs.getString("Email-ID");
              a+="\t";
              a+=rs.getString("Qualification");
              a+="\t";
              a+=rs.getString("Marks in last exam");
              a+="\t";
              a+=rs.getString("Address");
              a+="\n";   	               
          }
       
          
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
    }
    
    
    
    void dbselect1(String s1)
    {
        try
        {
     	   PreparedStatement ps=null;
     	   ResultSet rs=null;
     	  
     	  
     	  // String a=null,b=null,c=null;
            String val="select * from detail_student where Qualification ='"+s1+"' ";
          ps=con.prepareStatement(val);
          rs=ps.executeQuery();
          //System.out.println("Name\tID\tcontact");
         // System.out.println();
     

          a="Name\tSex\tContact\tEmail-ID\t             Qualification\t%Marks\tAddress\n";
          a+="\n\n";
          while(rs.next())
          {
        	  a+=rs.getString("Name");
              a+="\t";
              a+=rs.getString("Sex");
              a+="\t";
              a+=rs.getString("Contact");
              a+="\t";
              a+=rs.getString("Email-ID");
              a+="\t           ";
              a+=rs.getString("Qualification");
              a+="\t";
              a+=rs.getString("Marks in last exam");
              a+="\t";
              a+=rs.getString("Address");
              a+="\n";   	               
          }
       
          
        }
        catch(Exception e)
        {
            System.out.println("jain"+e.getMessage());
        }
    }
    
    
    
    
    
   
}
